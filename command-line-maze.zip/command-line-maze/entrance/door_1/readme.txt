You can explore this information, 
but this path does not lead deeper into the playoffs.

Consider returning to the previous decision. 